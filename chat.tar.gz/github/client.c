#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>


#define PORTNUMBER 9994
#define OK 1
#define ERROR 0


//判断在线情况标识符，1表示在线正常，2表示被踢下线，3表示被禁言
int *adress_online;
int mibao_flag;//密保答案通过后操作 1改密 0返回
int update_flag;//更新密码标志位 1 强制下线 0 正常
int siliao_flag;//私聊踢人发两次 1发两次 0发1次
typedef int Elementtype; 

//定义一个客户端的结构体
typedef struct client
{
    Elementtype id;
    Elementtype flag;
    Elementtype case_num;//功能选择
    Elementtype case_numnext;//发送登录成功聊天功能选择
    char name[100];//名字
    char password[150];//密码
    char pass_question[150];//密保问题
    char pass_answer[150];//密保答案
}Client_message;

//定义一个与服务器一致的结构体
typedef struct server
{
    Elementtype i_s;
    Elementtype num_s[50];
    Elementtype case_snum;//接收服务器进行的功能选择
    Elementtype id_s;
    Elementtype pass_flag;//密保是否正确
    char pass_q[150];
    char name_s[100];
    char password_s[150];
}Server_message;

Client_message msg_send;  //定义一个全局的客户端结构体,发送客户端的结构体
Server_message msg_accept;  //定义一个全局的客户端结构体，用于接收服务器的结构体

void *func(void *arg);

int main(int argc, char *argv[])
{
    int ret;
    system("clear");
    printf("############################正在启动客户端#############################\n");
    sleep(2);
    if (argc != 2)
    {
	printf("请正确输入ID\n");
	exit(0);
    }
    int socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == socket_fd)
    {
	perror("建立通信失败");
	exit(1);
    }
    struct sockaddr_in client_addr;

    memset(&client_addr, 0, sizeof(client_addr));

    client_addr.sin_family = AF_INET;
    client_addr.sin_port = htons(PORTNUMBER);
    client_addr.sin_addr.s_addr = inet_addr(argv[1]);

    if (-1 == connect(socket_fd, (struct sockaddr *)(&client_addr), sizeof(struct sockaddr)))
    {
	perror("连接服务器失败");
	exit(2);
    }
    printf("############################客户端启动成功#############################\n");
    sleep(2);
    printf("############################连接服务器成功#############################\n");

    char buff[1024] = {0};
    char sendbuff[1024] = {0};
    char BUFF[1024] = {0};
    pthread_t pid;//创建一个线程
    while(1)
    {
	system("banner welcome!");
	system("banner happychat");
	printf("-----------------------------欢迎来到聊天室------------------------------\n");
	printf("-----------------------------请选择以下功能------------------------------\n");
	printf("-------------------------------1. 注册-----------------------------------\n");
	printf("-------------------------------2. 登录-----------------------------------\n");
	printf("-------------------------------3. 退出-----------------------------------\n");
	printf("-----------------------------4. 忘记密码---------------------------------\n");
	printf("-------------------------------------------------------------------------\n");
	printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>请输入数字1 ～ 4: <<<<<<<<<<<<<<<<<<<<<<<<<<<\n");

	scanf("%d",&msg_send.case_num);
	switch(msg_send.case_num)
	{
	    case 1://注册
		{
		    char password_temp[150] = {0};
		    printf("请输入你要注册的名字:\n");
		    scanf("%s", msg_send.name);
		    printf("请输入你注册的密码:\n");
		    scanf("%s", msg_send.password);

		    printf("请再次输入你注册的密码:\n");
		    scanf("%s", password_temp);

		    printf("请输入你的密保问题:\n");
		    scanf("%s", msg_send.pass_question);
		    getchar();

		    printf("请输入你的密保答案：\n");
		    fgets(BUFF, 1024, stdin);
		    BUFF[strlen(BUFF) - 1] = '\0';
		    strncpy(msg_send.pass_answer, BUFF, sizeof(msg_send.pass_answer));


		    if(strcmp(msg_send.password,password_temp) != 0)
		    {
			printf("-------------------------------------------------------------\n");
			printf("两次输入的密码不一样，请重启注册.\n");
			printf("-------------------------------------------------------------\n");
			break;
		    }
		    memset(sendbuff,0,sizeof(sendbuff));
		    memcpy(sendbuff,&msg_send,sizeof(msg_send));
		    ret = send(socket_fd ,sendbuff, sizeof(sendbuff), 0);
		    if(ret <= 0)
		    {
			perror("发送失败");
			exit(1);
		    }
		    printf("你的注册信息已发送到服务器,请等待......\n");
		    sleep(2);

		    memset(buff,0,1024);
		    ret = recv(socket_fd, buff, sizeof(buff), 0);
		    if(ret <= 0)
		    {
			perror("接收服务器的消息失败");
			exit(1);
		    }
		    memset(&msg_accept,0,sizeof(msg_accept));
		    memcpy(&msg_accept, buff, sizeof(msg_accept));
		    if(msg_accept.case_snum == 0)
		    {
			printf("-------------------------------------------------------------------------\n");
			printf("恭喜你注册成功.你的登录的ID是:  %d\t 密码是:%s\n",msg_accept.id_s,password_temp);
			printf("-------------------------------------------------------------------------\n");
			memset(&msg_send,0,sizeof(msg_send));
			memset(&msg_accept,0,sizeof(msg_accept));
			update_flag = 0;//更新密码标志位
			break;
		    }
		    else
		    {
			printf("不好意思，你注册失败了.\n");
			memset(&msg_send,0,sizeof(msg_send));
			memset(&msg_accept,0,sizeof(msg_accept));
			break;
		    }
		}
	    case 2://登录
		{
		    int login_id;
		    memset(sendbuff,0,1024);
		    printf("请输入你要登录的ID:\n");
		    scanf("%d",&msg_send.id);
		    login_id = msg_send.id;
		    printf("请输入你登录的密码:\n");
		    scanf("%s",msg_send.password);
		    //把ID和密码发到服务器
		    memcpy(sendbuff,&msg_send,sizeof(msg_send));

		    ret = send(socket_fd ,sendbuff, sizeof(sendbuff), 0);
		    if(ret <= 0)
		    {
			perror("发送失败");
			exit(2);
		    }
		    printf("登录信息已发送到服务器，请稍等......\n");

		    memset(buff,0,1024);
		    ret = recv(socket_fd, buff, sizeof(buff), 0);//读取服务器发送的消息
		    if(ret <= 0)
		    {
			perror("接收服务器的消息失败");
			exit(1);
		    }

		    memcpy(&msg_accept, buff, sizeof(msg_accept));//把服务器传过来的套接字转换为结构体
		    if(msg_accept.case_snum == 2)//普通用户登录
		    {
			printf("#########################恭喜你普通用户登录成功#########################\n");
			update_flag = 0;//更新密码标志位
			int online = 1;
			siliao_flag = 0;
			adress_online = &online;
			//创建一个线程读出服务器发过来的消息

			ret = pthread_create(&pid, NULL,(void* )func, (void *)&socket_fd);
			if(-1 == ret)
			{
			     perror("创建线程失败");
			     exit(1);
			}

			while(1)
			{
			    if(2 == online || update_flag == 1)
			    {
				goto out;//完成踢人操作//改密退出
			    }
			    printf("************************************************************************\n");
			    printf("*****************************当前用户ID：%d***************************\n", login_id);
			    printf("************************************************************************\n");
			    printf("-----------------------------请选择以下功能-----------------------------\n");
			    printf("-------------------------------1.查看当前在线人数-----------------------\n");
			    printf("-------------------------------2.私聊-----------------------------------\n");
			    printf("-------------------------------3.群聊-----------------------------------\n");
			    printf("-------------------------------4.发送文件-------------------------------\n");
			    printf("-------------------------------5.注销-----------------------------------\n");
			    printf("-----------------------------6.更改密码---------------------------------\n");
			    printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>请输入数字1 ～ 6: <<<<<<<<<<<<<<<<<<<<<<<<<<\n");
			    scanf("%d",&msg_send.case_numnext);//登录成功后发送到服务器的请求
			    getchar();
			    if(2 == online)
			    {
				goto out;//完成踢人操作
			    }

			    switch(msg_send.case_numnext)
			    {
				case 1://看人数
				    {
					memset(sendbuff, 0, 1024);
					memcpy(sendbuff, &msg_send, sizeof(msg_send));
					ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}

					printf("已经向服务器发送请求，求稍等......\n");
					sleep(2);
					break;
				    }
				case 2://私聊
				    {
					siliao_flag = 1;
					if(online == 1)
					{
					    memset(sendbuff, 0, 1024);
					    printf("请输入你想要私聊的ID:\n");
					    scanf("%d",&msg_send.id);
					    getchar();
					    memcpy(sendbuff, &msg_send, sizeof(msg_send));
					    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					    if(ret <= 0)
					    {
						perror("发送失败");
						exit(1);
					    }
					    printf("已经向服务器发送请求，正在查询有无此ID,请稍等......\n");
					    sleep(2);


					    printf("如果查询ID存在，请输入你想要私聊的内容:(输入'byebye!'结束私聊)。如果查询ID不存在，请输入'exit',并重新选择私聊对象\n");
					    fgets(BUFF, 1024, stdin);
					    if(online == 3)
					    {
						strncpy(msg_send.name, "forbidden", 10);
						msg_send.id = login_id; 
						memcpy(sendbuff, &msg_send, sizeof(msg_send));

						ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
						if(ret <= 0)
						{
						    perror("发送失败");
						    exit(1);
						}
						
						break;
					    }
					    if(online == 2)
					    {
						break;
					    }
					    BUFF[strlen(BUFF) - 1] = '\0';
					    strncpy(msg_send.name, BUFF, sizeof(msg_send.name));
					    if(strcmp("exit", msg_send.name) == 0)
					    {
						break;
					    }
					    memcpy(sendbuff, &msg_send, sizeof(msg_send));
					    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					    if(ret <= 0)
					    {
						perror("发送失败");
						exit(1);
					    }
					    printf("已经向服务器发送消息请稍等......\n");
					    sleep(2);
					    while((strcmp("byebye!", msg_send.name) != 0) && (strcmp("exit", msg_send.name) != 0))
				            {
					        fgets(BUFF, 1024, stdin);
						if(online == 3)
						{
						    
						    strncpy(msg_send.name, "forbidden", 10);
						    msg_send.id = login_id;
						    memcpy(sendbuff, &msg_send, sizeof(msg_send));

						    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
						    if(ret <= 0)
						    {
							perror("发送失败");
							exit(1);
						    }
						    break;
						}
						if(online == 2)
						{
						    break;
						}
					        BUFF[strlen(BUFF) - 1] = '\0';
					        strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区
					        memcpy(sendbuff, &msg_send, sizeof(msg_send));

					        ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					        if(ret <= 0)
					        {
						    perror("发送失败");
						    exit(1);
					        }
					        printf("已经向服务器发送消息请稍等......\n");
					        sleep(2);
				            }
					}
					else
					{
					     printf("小伙子不好意思你被管理员禁言了\n");
					}
					break;
				    }
				case 3://群聊
				    {
					if(online == 1)
					{
					    memset(sendbuff, 0, 1024);
					    printf("请输入你想要群聊的内容,输入'byebye!'退出群聊发言:\n");
					    fgets(BUFF, 1024, stdin);
					    if(online == 3)
					    {
						strncpy(msg_send.name, "forbidden", 10);
						msg_send.id = login_id; 
						memcpy(sendbuff, &msg_send, sizeof(msg_send));

						ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
						if(ret <= 0)
						{
						    perror("发送失败");
						    exit(1);
						}
						break;
					    }
					    if(online == 2)
					    {
						break;
					    }
					    BUFF[strlen(BUFF) - 1] = '\0';
					    strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区

					    memcpy(sendbuff, &msg_send, sizeof(msg_send));
					    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					    if(ret <= 0)
					    {
						perror("发送失败");
						exit(1);
					    }
					    printf("已经向服务器发送消息请稍等......\n");
					    sleep(2);
					    while(strcmp("byebye!", msg_send.name) != 0)
				            {
					        fgets(BUFF, 1024, stdin);
						if(online == 3)
						{
						    strncpy(msg_send.name, "forbidden", sizeof(msg_send.name));
						    msg_send.id = login_id;
						    memcpy(sendbuff, &msg_send, sizeof(msg_send));

						    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
						    if(ret <= 0)
						    {
							perror("发送失败");
							exit(1);
						    }
						    break;
						}
						if(online == 2)
						{
						    break;
						}
					        BUFF[strlen(BUFF) - 1] = '\0';
					        strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区
					        memcpy(sendbuff, &msg_send, sizeof(msg_send));

					        ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					        if(ret <= 0)
					        {
						    perror("发送失败");
						    exit(1);
					        }
					        printf("已经向服务器发送消息请稍等......\n");
					        sleep(2);
				            }
					}
					else
					{
					    printf("小伙子不好意思你被管理员禁言了\n");
					}
					break;
				    }
				case 4:
				    {
					 if(3 != online)
					 {
					     //先把名字发过去
					     memset(sendbuff, 0, 1024);

					     printf("请输入接收文件人ID:\n");
					     scanf("%d",&msg_send.id);

					     printf("请输入你发送文件的名字:\n");
					     scanf("%s",msg_send.name);

					     memcpy(sendbuff, &msg_send, sizeof(msg_send));

					      ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					      if(ret <= 0)
					      {
						  perror("发送失败");
						  exit(1);
					      }

					      //再把内容发过去,创建一个与上面一样的名字
					      FILE *fp = fopen(msg_send.name,"r");
					      if(NULL == fp)
					      {
						   perror("打开失败");
						   exit(1);
					      }
					      else
					      { 
						  char buffer_file[1024];
						  memset(buffer_file, 0, 1024);
						  int file_block_length = 0;
						  while( (file_block_length = fread(buffer_file, sizeof(char), 1024, fp)) > 0)
						  {
						      printf("length = %d\n",file_block_length);
						      if(send(socket_fd, buffer_file, file_block_length, 0) < 0)
						      {
							  printf("发送失败1\n");
							  break;
						      }
						      memset(buffer_file, 0, 1024);
						  }
						  fclose(fp);

						  strncpy( buffer_file , "END", 4);
						  printf("client (发送) buffer is %s\n", buffer_file);
						  sleep(1);
						  if(send(socket_fd, buffer_file, 10, 0) < 0)
						  {
						      printf("发送失败\n");
						      break;
						  }
					      }
					      sleep(2);
					 }
					 else
					 {
					     printf("小伙子不好意思你被管理员禁言了,不能发送文件\n");
					 }
					 break;
				    }
				case 5:
				    {
					memset(sendbuff, 0, 1024);
					char str_temp[10];

					printf("你是否想要下线 ？输入: yes 确定下线 ，输入: no 撤回请求 \n");
					scanf("%s",str_temp);

					if(strcmp(str_temp, "yes") == 0)
					{
					    memcpy(sendbuff, &msg_send, sizeof(msg_send));
					    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					    if(ret <= 0)
					    {
						perror("发送失败");
						exit(1);
					    }
					    printf("已经向服务器发送下线请求，请稍等......\n");
					     goto out;
					}
					break;
				    }
				case 6:
				    {
					memset(sendbuff, 0, sizeof(sendbuff));
					msg_send.case_numnext = 9;
					memcpy(sendbuff, &msg_send, sizeof(msg_send));
					ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}
					printf("已经向服务器发送请求，请稍等......\n");
					sleep(2);
					printf("\n请输入密保答案\n");
					fgets(BUFF, sizeof(BUFF), stdin);
					BUFF[strlen(BUFF) - 1] = '\0';
					strncpy(msg_send.pass_answer, BUFF, sizeof(msg_send.pass_question));
					printf("answer = %s\n", msg_send.pass_answer);
					msg_send.case_numnext = 10;
					memset(sendbuff, 0, sizeof(sendbuff));
					memcpy(sendbuff, &msg_send, sizeof(msg_send));
					ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}
					printf("已经向服务器发送请求，请稍等......\n");
					sleep(2);
					if(mibao_flag == 1)
					{
					    char password_temp[150] = {0};
					    new_passI:
					    printf("\n请输入新的密码\n");
					    scanf("%s", msg_send.password);

					    printf("请再次输入你的新密码:\n");
					    scanf("%s", password_temp);

					    if(strcmp(msg_send.password,password_temp) != 0)
					    {
						printf("-------------------------------------------------------------\n");
						printf("两次输入的密码不一样，请重新输入.\n");
						printf("--------------------------------------------------------------\n");
						goto new_passI;
					    }
					    msg_send.case_numnext = 11;
					    memset(sendbuff,0,sizeof(sendbuff));
					    memcpy(sendbuff,&msg_send,sizeof(msg_send));
					    ret = send(socket_fd ,sendbuff, sizeof(sendbuff), 0);
					    if(ret <= 0)
					    {
						perror("发送失败");
						exit(1);
					    }
					    printf("你的修改信息已发送到服务器,请等待......\n");
					    sleep(2);
					    break;
					}
					else
					{
					    break;
					}
				    }
			    }
			}
			break;
		    }
		    if(msg_accept.case_snum == 1)  //登录失败
		    {
			printf("登录信息有误，请重新登录...\n");
			memset(&msg_send,0,sizeof(msg_send));
			memset(&msg_accept,0,sizeof(msg_accept));
			break;
		    }
		    if(msg_accept.case_snum == 3)//管理员登录
		    {
			 printf("***************************恭喜你管理员登录成功**************************\n");
			 update_flag = 0;
		    }

		    ret = pthread_create(&pid, NULL,(void* )func, (void *)&socket_fd);
		    if(-1 == ret)
		    {
			perror("创建线程失败");
			exit(1);
		    }

		    while(1)
		    {
			if(update_flag == 1)//改密强制下线;
			{
			    goto out;
			}
			printf("------------------------管理员你好,请选择以下功能------------------------\n");
			printf("-------------------------1.查看当前在线人数------------------------------\n");
			printf("-------------------------------2.私聊------------------------------------\n");
			printf("-------------------------------3.群聊------------------------------------\n");
			printf("------------------------------4.发送文件---------------------------------\n");
			printf("-------------------------------5.注销------------------------------------\n");
			printf("-------------------------------6.禁言------------------------------------\n");
			printf("-------------------------------7.解禁------------------------------------\n");
			printf("-------------------------------8.踢人------------------------------------\n");
			printf("-----------------------------9.更改密码----------------------------------\n");
			printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>请输入数字1 ～ 9: <<<<<<<<<<<<<<<<<<<<<<<<<<<\n");

			scanf("%d",&msg_send.case_numnext);
			getchar();

			switch(msg_send.case_numnext)
			{
			    case 1://查看在线人数
				{
				    memset(sendbuff, 0, 1024);
				    memcpy(sendbuff, &msg_send, sizeof(msg_send));

				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }

				    printf("已经向服务器发送请求，求稍等......\n");
				    sleep(2);
				    break;
				}
			    case 2://私聊
				{
				    memset(sendbuff, 0, 1024);
				    printf("请输入你想要私聊的ID:\n");
				    scanf("%d",&msg_send.id);
				    getchar();
				    memcpy(sendbuff, &msg_send, sizeof(msg_send));
				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求，正在查询有无此ID,请稍等......\n");
				    sleep(2);


				    printf("如果查询ID存在，请输入你想要私聊的内容:(输入'byebye!'结束私聊)。如果查询ID不存在，请输入'exit',并重新选择私聊对象\n");
			            fgets(BUFF, 1024, stdin);
			            BUFF[strlen(BUFF) - 1] = '\0';
				    strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区
				    if(strcmp("exit", msg_send.name) == 0)
				    {
					break;
				    }
				    memcpy(sendbuff, &msg_send, sizeof(msg_send));
				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送消息请稍等......\n");
				    sleep(2);
				    while((strcmp("byebye!", msg_send.name) != 0) && (strcmp("exit", msg_send.name) != 0))
				    {
					fgets(BUFF, 1024, stdin);
					BUFF[strlen(BUFF) - 1] = '\0';
					strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区
					memcpy(sendbuff, &msg_send, sizeof(msg_send));

					ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}
					printf("已经向服务器发送消息请稍等......\n");
					sleep(2);
				    }
				    break;
				}
			    case 3://群聊
				{
				    memset(sendbuff, 0, 1024);
				    printf("请输入你想要群聊的内容,输入'byebye!'退出群聊发言:\n");
			            fgets(BUFF, 1024, stdin);
			            BUFF[strlen(BUFF) - 1] = '\0';
				    strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区

				    memcpy(sendbuff, &msg_send, sizeof(msg_send));
				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送消息请稍等......\n");
				    sleep(2);
				    while(strcmp("byebye!", msg_send.name) != 0)
				    {
				        fgets(BUFF, 1024, stdin);
					BUFF[strlen(BUFF) - 1] = '\0';
					strncpy(msg_send.name, BUFF, sizeof(msg_send.name));//用名字暂作缓冲区
					memcpy(sendbuff, &msg_send, sizeof(msg_send));

					ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}
					printf("已经向服务器发送消息请稍等......\n");
					sleep(2);
				    }
				    break;
				}
			    case 4://发送文件
				{
				    //先把名字发过去
				    memset(sendbuff, 0, 1024);

				    printf("请输入接收文件人ID:\n");
				    scanf("%d",&msg_send.id);
				    getchar();

				    printf("请输入你发送文件的名字:\n");
				    scanf("%s",msg_send.name);

				    memcpy(sendbuff, &msg_send, sizeof(msg_send));

				     ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				     if(ret <= 0)
				     {
					 perror("发送失败");
					 exit(1);
				     }

				     //再把内容发过去,创建一个与上面一样的名字
				     FILE *fp = fopen(msg_send.name,"r");
				     if(NULL == fp)
				     {
					  perror("打开失败");
					  exit(1);
				     }
				     else
				     {
					 char buffer_file[1024];
					 memset(buffer_file, 0, sizeof(buffer_file));
					 int file_block_length = 0;
					 while( (file_block_length = fread(buffer_file, sizeof(char), 1024, fp)) > 0)
					 {
					     printf("length = %d\n",file_block_length);
					     if(send(socket_fd, buffer_file, sizeof(buffer_file), 0) < 0)
					     {
						 printf("发送失败1\n");
						 break;
					     }
					     memset(buffer_file, 0, sizeof(buffer_file));
					 }
					 fclose(fp);
					 memset(buffer_file, 0, sizeof(buffer_file));
					 strncpy( buffer_file , "END", 4);
					 printf("发送结束\n");
					 sleep(1);
					 if(send(socket_fd, buffer_file, sizeof(buffer_file), 0) < 0)
					 {
					     printf("发送失败\n");
					     break;
					 }
				     }
				     sleep(2);
				     break;
				}
			    case 5://注销
				{
				    memset(sendbuff, 0, 1024);
				    char str_temp[100];

				    printf("你是否想要下线 ？输入: yes 确定下线 ，输入: no 撤回请求 \n");
				    scanf("%s",str_temp);

				     if(strcmp(str_temp, "yes") == 0)
				     {
					 memcpy(sendbuff, &msg_send, sizeof(msg_send));
					  ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
					  if(ret <= 0)
					  {
					      perror("写入失败");
				              exit(1);
					  }
					  printf("已经向服务器发送下线请求，请稍等......\n");
					      goto out;
				     }
				     else
				     {
					 break;
				     }
				}
			    case 6://禁言
				{
				    memset(sendbuff, 0, 1024);

				    printf("请输入你想要禁言的ID:\n");
				    scanf("%d",&msg_send.id);

				    memcpy(sendbuff, &msg_send, sizeof(msg_send));

				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求, 请稍等......\n");
				    sleep(2);
				    break;
				}
			    case 7://解禁
				{
				    memset(sendbuff, 0, 1024);

				    printf("请输入你想要解禁的ID:\n");
				    scanf("%d",&msg_send.id);

				    memcpy(sendbuff, &msg_send, sizeof(msg_send));

				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(-1 == ret)
				    {
					perror("写入失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求,请稍等......\n");
				    sleep(2);
				    break;
				}
			    case 8://踢人下线
				{
				    memset(sendbuff, 0, 1024);

				    printf("请输入你想要踢人的ID:\n");
				    scanf("%d",&msg_send.id);

				    memcpy(sendbuff, &msg_send, sizeof(msg_send));

				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求，请稍等......\n");
				    sleep(2);
				    break;
				}
			    case 9://改密
				{
				    memset(sendbuff, 0, sizeof(sendbuff));
				    memcpy(sendbuff, &msg_send, sizeof(msg_send));
				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求，请稍等......\n");
				    sleep(2);
				    printf("\n请输入密保答案\n");
				    fgets(BUFF, sizeof(BUFF), stdin);
				    BUFF[strlen(BUFF) - 1] = '\0';
				    strncpy(msg_send.pass_answer, BUFF, sizeof(msg_send.pass_question));
				    msg_send.case_numnext = 10;
				    memset(sendbuff, 0, sizeof(sendbuff));
				    memcpy(sendbuff, &msg_send, sizeof(msg_send));
				    ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
				    if(ret <= 0)
				    {
					perror("发送失败");
					exit(1);
				    }
				    printf("已经向服务器发送请求，请稍等......\n");
				    sleep(2);
				    if(mibao_flag == 1)
				    {
					char password_temp[150] = {0};
					new_pass:
					printf("\n请输入新的密码\n");
					scanf("%s", msg_send.password);

					printf("请再次输入你的新密码:\n");
					scanf("%s", password_temp);

					if(strcmp(msg_send.password,password_temp) != 0)
					{
					    printf("-------------------------------------------------------------------------\n");
					    printf("两次输入的密码不一样，请重新输入.\n");
					    printf("-------------------------------------------------------------------------\n");
					    goto new_pass;
					}
					msg_send.case_numnext = 11;
					memset(sendbuff,0,sizeof(sendbuff));
					memcpy(sendbuff,&msg_send,sizeof(msg_send));
					ret = send(socket_fd ,sendbuff, sizeof(sendbuff), 0);
					if(ret <= 0)
					{
					    perror("发送失败");
					    exit(1);
					}
					printf("你的修改信息已发送到服务器,请等待......\n");
					sleep(2);
					break;
				    }
				    else
				    {
					break;
				    }
				}
			}
		    }
		    break;
		}
	    case 3://退出程序
	    {
	        memset(sendbuff, 0, 1024);//清空发送缓存
	        memcpy(sendbuff, &msg_send, sizeof(msg_send)); //结构体转换成字符串

	        ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);//发送信息
	        if(ret <= 0)
	        {
		    perror("写入失败");
		    exit(1);
	        }
	        goto outroom;
	    }
	    case 4://忘记密码
	    {
		printf("请输入你的id\n");
		scanf("%d", &msg_send.id);
		getchar();
	        memset(sendbuff, 0, 1024);//清空发送缓存
	        memcpy(sendbuff, &msg_send, sizeof(msg_send)); //结构体转换成字符串

	        ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);//发送信息
	        if(ret <= 0)
	        {
		    perror("发送失败");
		    exit(1);
	        }

	        memset(buff,0,1024);
		ret = recv(socket_fd, buff, sizeof(buff), 0);
		if(ret <= 0)
		{
		    perror("接收服务器的消息失败");
		    exit(1);
		}
		memset(&msg_accept,0,sizeof(msg_accept));
		memcpy(&msg_accept, buff, sizeof(msg_accept));
	       	printf("密保问题:\n");
		printf("%s\n", msg_accept.pass_q);
		printf("请输入密保答案:\n");

		fgets(BUFF, sizeof(BUFF), stdin);
		BUFF[strlen(BUFF) - 1] = '\0';
		strncpy(msg_send.pass_answer, BUFF, sizeof(msg_send.pass_question));
		memset(sendbuff, 0, sizeof(sendbuff));
		memcpy(sendbuff, &msg_send, sizeof(msg_send));
		ret = send(socket_fd, sendbuff, sizeof(sendbuff), 0);
		if(ret <= 0)
		{
		    perror("发送失败");
		    exit(1);
		}
		printf("已经向服务器发送请求，请稍等......\n");
		
		//接收密保问题是否正确
	        memset(buff,0,1024);
		ret = recv(socket_fd, buff, sizeof(buff), 0);
		if(ret <= 0)
		{
		    perror("接收服务器的消息失败");
		    exit(1);
		}
		memset(&msg_accept,0,sizeof(msg_accept));
		memcpy(&msg_accept, buff, sizeof(msg_accept));
		if(msg_accept.pass_flag == 1)
		{
		    printf("密保问题验证成功\n");
		    char password_temp[150] = {0};
		    new_passII:
		    printf("\n请输入新的密码\n");
		    scanf("%s", msg_send.password);

		    printf("请再次输入你的新密码:\n");
		    scanf("%s", password_temp);

		    if(strcmp(msg_send.password,password_temp) != 0)
		    {
			printf("-------------------------------------------------------------------------\n");
			printf("两次输入的密码不一样，请重新输入.\n");
			printf("-------------------------------------------------------------------------\n");
			goto new_passII;
		    }
		    memset(sendbuff,0,sizeof(sendbuff));
		    memcpy(sendbuff,&msg_send,sizeof(msg_send));
		    ret = send(socket_fd ,sendbuff, sizeof(sendbuff), 0);
		    if(ret <= 0)
		    {
			perror("发送失败");
			exit(1);
		    }
		    printf("你的修改信息已发送到服务器,请等待......\n");
		    memset(buff,0,1024);
		    ret = recv(socket_fd, buff, sizeof(buff), 0);
		    if(ret <= 0)
		    {
			perror("接收服务器的消息失败");
			exit(1);
		    }
		    memset(&msg_accept,0,sizeof(msg_accept));
		    memcpy(&msg_accept, buff, sizeof(msg_accept));
		    printf("%s\n", msg_accept.name_s);
		}
		else
		{
		    printf("密保问题验证失败\n");
		}
		break;
	    }
	}
out:
    printf("-------------------------------------------------------------------------\n");
    sleep(1);
    }

outroom:
close(socket_fd);
system("cowsay bye!bye!");

return 0;
}

void *func(void *arg)
{
    int ret;
    int socket_fd = *(int*)arg;
    char buff[1024] = {0};

    while(1)
    {
	ret = recv(socket_fd, buff, sizeof(buff), 0);//把服务器传来的消息读到buff
	if(ret < 0)
	{
	    perror("读取服务器失败");
	    exit(1);
	}
	memset(&msg_accept, 0, sizeof(msg_accept));//清空结构体
	memcpy(&msg_accept, buff, sizeof(msg_accept));//把接收到的信息转换成结构体
	switch(msg_accept.case_snum)
	{
	    case 6: //查询在线人数
		{
		    printf("在线人数为 : %d ，分别为如下 ：\n",msg_accept.id_s);
		    int i;

		    for(i = 0;i < msg_accept.i_s;i++)
		    {
			printf("ID = %d\n",msg_accept.num_s[i]); 
		    }
		    break;
		}
	    case 4:
		{
		    printf("查询成功,有这个ID,他的客户端为 : %d\n",msg_accept.id_s);
		    break;
		}
	    case 5:
		{
		    printf("查询失败，没有这个ID, 请输入'exit',并重新选择私聊对象\n");
		    break;
		}
	    case 7:
		{
		    printf("ID为%d的人给你发来消息,消息是:%s\n",msg_accept.id_s,msg_accept.name_s);
		    break;
		}
	    case 8:
		{
		    printf("你的消息已发送成功\n");
		    break;
		}
	    case 9:
		{
		    printf("ID为%d的人给发来了群聊消息，消息是 : %s\n",msg_accept.id_s,msg_accept.name_s);
		    break;
		}
	    case 10:
		{
		    printf("你的群聊消息已发送成功\n");
		    break;
		}
	    case 11:
		{
		    printf("你已经下线成功\n");
		    goto out_1;
		}
	    case 12:
		{
		    printf("小伙子不好意思你被管理员禁言了\n");
		    *adress_online = 3; 
		    break; 
		}
	    case 13:
		{
		    printf("禁言成功了\n");
		    break;
		}
	    case 14:
		{
		    printf("小伙子运气不错,你被管理员解禁了\n");
		    *adress_online = 1;
		    break;
		}
	    case 15:
		{
		    printf("解禁成功，他又可以说话了\n");
		    break;
		}
	    case 16:
		{
		    printf("小伙子不好意思你被管理员踢出去了,请输入任意数字返回主界面\n");
		    char sendbuff_temp[1024] = {0};
		    msg_send.case_numnext = 5;
		    memcpy(sendbuff_temp, &msg_send, sizeof(msg_send)); //结构体转换成字符串

		    *adress_online = 2;
		    ret = send(socket_fd, sendbuff_temp, sizeof(sendbuff_temp), 0);//发送信息
		    if(ret <= 0)
		    {
			perror("发送失败");
			exit(1);
		    }
		    if(siliao_flag == 1)
		    {
		        ret = send(socket_fd, sendbuff_temp, sizeof(sendbuff_temp), 0);//发送信息
		        if(ret <= 0)
		        {
			    perror("发送失败");
			    exit(1);
		        }
		    }
		    break;
		}
	    case 17:
		{
		    printf("踢人操作成功\n");
		    break;
		}
	    case 18://文件传输
		{
		    printf("ID为: %d的人给你发来了文件,文件名是 :%s\n",msg_accept.id_s,msg_accept.name_s);
		    char buffer_file[1024];
		    char *str;

		    str = strrchr(msg_accept.name_s, '/');

		    FILE * fp = fopen(str + 1,"w");
		    if(NULL == fp )
		    {
			perror("打开失败"); 
			exit(1);
		    }

		    memset(buffer_file, 0, sizeof(buffer_file));

		    int length = 0;
		    while(1)
		    {
			length = recv(socket_fd, buffer_file, sizeof(buffer_file), 0);
			if(length < 0)
			{
			    perror("读入失败");
			    break;
			}

			if(0 == strcmp(buffer_file, "END"))
			{
			    printf("文件接收完成\n");
			    break;
			}

			int write_length = fwrite(buffer_file, sizeof(char), length, fp);
			if(write_length < length)
			{
			    perror("写入失败");
			    break;
			}
		    }
		    fclose(fp);
		    break;
		}
	    case 19:
		{
		     printf("发送成功\n");
		     break;
		}
	    case 20://接收改密问题
		{
		    printf("请回答密保问题:\n");
		    printf("%s\n", msg_accept.pass_q);
	            break;
		}
	    case 21://验证密保答案
		{
		    if(msg_accept.pass_flag == 1)
		    {
			printf("密保答案正确\n");
			mibao_flag = 1;
		    }
		    else
		    {
			printf("密保答案错误\n");
			mibao_flag = 0;
		    }
		    break;
		}
	    case 22://更新密码
		{
		    printf("你的密码更改成功\n");
		    
		    char sendbuff_temp[1024] = {0};
		    msg_send.case_numnext = 5;
		    memcpy(sendbuff_temp, &msg_send, sizeof(msg_send)); //结构体转换成字符串

		    ret = send(socket_fd, sendbuff_temp, sizeof(sendbuff_temp), 0);//发送信息
		    if(ret <= 0)
		    {
			perror("发送失败");
			exit(1);
		    }
		    update_flag = 1; 

		    break;
		}
	}
    }
out_1:
    printf("-------------------------------------------------------------------------\n");
    pthread_exit(NULL);
}

