直接运行 chat.sh 即可！！！
